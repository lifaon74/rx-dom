export * from './compile-default-modifier-property';

