import { IGenericElementModifierFunction } from './element-modifier-function.type';

export interface IGetElementModifierFunction {
  (name: string): IGenericElementModifierFunction;
}
