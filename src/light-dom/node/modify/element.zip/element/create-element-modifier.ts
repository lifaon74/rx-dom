import { freeze } from '@lifaon/rx-js-light';
import { IGenericElementModifierFunction } from './element-modifier-function.type';
import { IElementModifier } from './element-modifier.type';

export function createElementModifier<GName extends string, GElementModifierFunction extends IGenericElementModifierFunction>(
  name: GName,
  modify: GElementModifierFunction,
): IElementModifier<GName, GElementModifierFunction> {
  return freeze({
    name,
    modify,
  });
}
