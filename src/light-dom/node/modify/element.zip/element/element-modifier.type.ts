import { IGenericElementModifierFunction } from './element-modifier-function.type';

export interface IElementModifier<GName, GElementModifierFunction extends IGenericElementModifierFunction> {
  readonly name: GName;
  readonly modify: GElementModifierFunction;
}

export type IGenericElementModifier = IElementModifier<string, IGenericElementModifierFunction>;

