export interface IElementModifierFunction<GArguments extends any[], GOutNode extends Node> {
  (
    node: Element,
    ...args: GArguments
  ): GOutNode;
}

export type IGenericElementModifierFunction = IElementModifierFunction<any, Node>;



