import { freeze } from '@lifaon/rx-js-light';
import { IGenericHTMLElementModifierFunction } from './html-element-modifier-function.type';
import { IHTMLElementModifier } from './html-element-modifier.type';

export function createElementModifier<GName extends string, GHTMLElementModifierFunction extends IGenericHTMLElementModifierFunction>(
  name: GName,
  modify: GHTMLElementModifierFunction,
): IHTMLElementModifier<GName, GHTMLElementModifierFunction> {
  return freeze({
    name,
    modify,
  });
}
