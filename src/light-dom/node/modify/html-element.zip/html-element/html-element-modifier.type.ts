import { IGenericHTMLElementModifierFunction } from './html-element-modifier-function.type';

export interface IHTMLElementModifier<GName, GHTMLElementModifierFunction extends IGenericHTMLElementModifierFunction> {
  readonly name: GName;
  readonly modify: GHTMLElementModifierFunction;
}

export type IGenericHTMLElementModifier = IHTMLElementModifier<string, IGenericHTMLElementModifierFunction>;

