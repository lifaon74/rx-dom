
export interface IHTMLElementModifierFunction<GArgument, GOutNode extends Node> {
  (node: HTMLElement, arg: GArgument): GOutNode;
}

export type IGenericHTMLElementModifierFunction = IHTMLElementModifierFunction<any, Node>;

