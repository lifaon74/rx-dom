export function getElementStyleDeclaration(
  element: HTMLElement,
): CSSStyleDeclaration {
  return element.style;
}

