import { IStylePropertyObjectWithOptionalPriorityOrNull } from '../../../../light-dom/style/style-property.type';

export type IStylesMap = Map<string, IStylePropertyObjectWithOptionalPriorityOrNull>;

