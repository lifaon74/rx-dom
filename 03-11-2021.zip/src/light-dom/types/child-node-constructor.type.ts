export interface ChildNodeConstructor {
  new(...args: any[]): ChildNode;
}
