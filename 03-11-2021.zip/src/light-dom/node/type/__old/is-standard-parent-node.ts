// import { isElementNode } from './is-element';
// import { ContainerNode } from '../create/container-node/container-node';
// import { isContainerNode } from './is-container-node';
//
// export type IStandardParentNode = Element | ContainerNode;
//
// export function isStandardParentNode(
//   node: Node,
// ): node is IStandardParentNode {
//   return isElementNode(node)
//     || isContainerNode(node);
// }
//
//
