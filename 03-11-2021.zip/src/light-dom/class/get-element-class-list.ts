export function getElementClassList(
  element: Element,
): DOMTokenList {
  return element.classList;
}

