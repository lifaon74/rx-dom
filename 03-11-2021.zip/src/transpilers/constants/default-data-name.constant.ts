export const DEFAULT_DATA_NAME = '$';
