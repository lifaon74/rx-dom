export const DEFAULT_CONTENT_NAME = '$content';
