export type ILines = string[];

export type ILinesOrNull = ILines | null;

