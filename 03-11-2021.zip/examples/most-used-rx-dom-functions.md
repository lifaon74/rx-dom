# Most used rx-dom functions


- [bootstrap](../src/misc/bootstrap/bootstrap.md)
- [onNodeConnectedToWithImmediateCached](../src/light-dom/node/state/on-node-connected-to/on-node-connected-to.md)
- [subscribeOnNodeConnectedTo](../src/misc/subscribe-on-node-connected-to/subscribe-on-node-connected-to.md)
- [compileReactiveHTMLAsGenericComponentTemplate](../src/component/component-template/compile/compile-reactive-html-as-generic-component-template.md)
- [compileReactiveCSSAsComponentStyle](../src/component/component-style/compile/compile-reactive-css-as-component-style.md)
- [createElementModifier, generateGetNodeModifierFunctionFromArray](./node-modifiers.md)

