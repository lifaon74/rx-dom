export type IStringOrURL = string | URL;

