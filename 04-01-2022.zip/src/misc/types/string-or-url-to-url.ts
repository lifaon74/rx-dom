import { IStringOrURL } from './string-or-url.type';
import { getBaseURI } from '../../light-dom/node/explore/get-base-uri';

export function stringOrURLToURL(
  input: IStringOrURL,
): URL {
  return (typeof input === 'string')
    ? new URL(input, getBaseURI())
    : input;
}
