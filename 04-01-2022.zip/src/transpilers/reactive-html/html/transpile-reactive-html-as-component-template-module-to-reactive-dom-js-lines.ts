import { IComponentTemplateCompileOptions } from '../../../component/component-template/component-template.type';
import { IObjectProperties } from '../../helpers/generate-object-properties-lines';
import { indentLines } from '../../helpers/lines-formatting-helpers';
import { ILines } from '../../types/lines.type';
import { transpileReactiveHTMLAsComponentTemplateFunctionToReactiveDOMJSLines } from './transpile-reactive-html-as-component-template-function-to-reactive-dom-js-lines';

export function transpileReactiveHTMLAsComponentTemplateModuleToReactiveDOMJSLines(
  html: string,
  constantsToImport?: IObjectProperties,
  options?: IComponentTemplateCompileOptions,
): ILines {
  return [
    `"use strict";`,
    `export default (`,
    ...indentLines(transpileReactiveHTMLAsComponentTemplateFunctionToReactiveDOMJSLines(html, constantsToImport, options)),
    `);`,
  ];
}


