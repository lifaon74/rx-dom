export function getNodeType(
  node: Node,
): number {
  return node.nodeType;
}
