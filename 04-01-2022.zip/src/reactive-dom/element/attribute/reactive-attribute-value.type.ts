import { IAttributeValueOrNull } from '../../../light-dom/attribute/attribute-value.type';

export type IReactiveAttributeValue = IAttributeValueOrNull;
