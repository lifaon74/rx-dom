
export function getShadowRoot(
  node: Element,
): ShadowRoot | null {
  return node.shadowRoot;
}


