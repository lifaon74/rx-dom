
export function getTagName(
  node: Element,
): string {
  return node.tagName.toLowerCase();
}
