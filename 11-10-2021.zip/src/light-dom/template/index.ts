export * from './attach-template';
export * from './is-html-template';
export * from './template.type';
