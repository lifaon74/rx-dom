export function getCustomElementRegistry(): CustomElementRegistry {
  return globalThis.customElements;
}
