import { idle, of, reactiveFunction, single } from '@lifaon/rx-js-light';

export const DEFAULT_FROM_CONSTANTS_TO_IMPORT = {
  of,
  single,
  idle,
  func: reactiveFunction,
};



