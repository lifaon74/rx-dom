import { reactiveAnd, reactiveNot, reactiveOr } from '@lifaon/rx-js-light';

export const DEFAULT_LOGIC_CONSTANTS_TO_IMPORT = {
  and: reactiveAnd,
  or: reactiveOr,
  not: reactiveNot,
};



