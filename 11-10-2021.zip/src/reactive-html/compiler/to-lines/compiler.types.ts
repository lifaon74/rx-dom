export type ILines = string[];

export type ICompilerReturn = ILines | null;

