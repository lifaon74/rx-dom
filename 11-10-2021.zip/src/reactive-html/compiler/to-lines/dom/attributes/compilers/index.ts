export * from './compile-default-attributes';

