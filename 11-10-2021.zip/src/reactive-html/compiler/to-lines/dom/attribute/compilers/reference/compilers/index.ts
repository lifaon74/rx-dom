export * from './compile-default-reference-property';

