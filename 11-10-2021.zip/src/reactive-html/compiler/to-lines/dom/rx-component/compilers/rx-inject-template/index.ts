export * from './compile-rx-inject-template';

