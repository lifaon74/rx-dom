// import { enableComponentTemplateAOT } from '../component/component-template/aot/register-component-template-for-aot';
//
//
// export interface IEnableAOTOptions {
//   componentTemplateAOT: (componentId: string) => void;
// }
//
//
// export function enableAOT(
//   options: IEnableAOTOptions,
// ): void {
//   enableComponentTemplateAOT();
// }
