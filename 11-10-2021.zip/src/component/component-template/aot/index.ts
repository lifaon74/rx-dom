// export * from './register-component-template-for-aot';

