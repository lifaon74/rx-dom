export * from './load-compile-and-evaluate-reactive-html-as-component-template';


