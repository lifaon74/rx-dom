export * from './generate-constants-to-import-for-component-template-from-object';
export * from './inject-component-template';

