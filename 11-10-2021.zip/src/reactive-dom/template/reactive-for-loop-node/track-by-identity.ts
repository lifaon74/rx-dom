export function trackByIdentity<GItem>(
  item: GItem,
): GItem {
  return item;
}
