import { IAttributeValue } from '../../../light-dom';

export type IReactiveAttributeValue = IAttributeValue;
