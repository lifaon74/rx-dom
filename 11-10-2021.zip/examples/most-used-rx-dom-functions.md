# Most used rx-dom functions


- [bootstrap](../src/misc/bootstrap/bootstrap.md)
- [onNodeConnectedToWithImmediateCached](../src/light-dom/node/state/on-node-connected-to/on-node-connected-to.md)
- [subscribeOnNodeConnectedTo](../src/misc/subscribe-on-node-connected-to/subscribe-on-node-connected-to.md)
- [compileAndEvaluateReactiveHTMLAsComponentTemplate](../src/component/component-template/compile/with-evaluation/compile-and-evaluate-reactive-html-as-component-template.md)
- [compileReactiveCSSAsComponentStyle](../src/component/component-style/compile/compile-reactive-css-as-component-style.md)
- [createElementModifier, generateGetNodeModifierFunctionFromArray](./node-modifiers.md)

